import argparse
import torch
import torchvision
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torchvision.models as models
from collections import OrderedDict
import matplotlib.pyplot as plt
import numpy as np
import json
from PIL import Image
from torch.autograd import Variable
import torchvision.models as models

from torch import nn, optim
import train 




parser = argparse.ArgumentParser(
    description = 'Parser for predict.py'
)

parser.add_argument('input', default='./flowers/test/1/image_06752.jpg', nargs='?', action="store", type = str)
parser.add_argument('--dir', action="store",dest="data_dir", default="./flowers/")

parser.add_argument('--top_k', default=5, dest="top_k", action="store", type=int)
parser.add_argument('--category_names', dest="category_names", action="store", default='cat_to_name.json')
parser.add_argument('--gpu', default="gpu", action="store", dest="gpu")

args = parser.parse_args()
path_image = args.input
number_of_outputs = args.top_k
device = args.gpu
def save_checkpoint(Model, train_datasets, save_dir):
    Model.class_to_idx = train_datasets.class_to_idx
    checkpoint = {'structure': Model.name,
                  'classifier': Model.classifier,
                  'state_dict': model.state_dict()}
    return torch.save(checkpoint, save_dir)
# TODO: Write a function that loads a checkpoint and rebuilds the model
def load_checkpoint(filepath):
    checkpoint = torch.load(filepath)
    model = (checkpoint["input_size"],
             checkpoint["output_size"],
             checkpoint["arch"])
    model.load_state_dict(checkpoint["state_dict"])
    
    return model
defload_cat_names(filename):
     with open(filename) as f:
 category_names = jason.load(f)
return category_names

def predict(image_path, model, topk=5):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
    
    # TODO: Implement the code to predict the class from an image file
    process_img = torch.from_numpy(process_image(image_path))
    process_img.unsqueeze_(0)
    process_img = process_img.type(torch.FloatTensor)
    
    with torch.no_grad():
        output = model.foward(ps_img)
        probs, top_classes = output.topk(topk, dim= 1)
    return probs, top_classes
                         
def main():
    model= load_checkpoint(filepath)
    with open('cat_to_name.json', 'r') as json_file:
        cat_to_name = json.load(json_file)
        
    probabilities = predict(path_image, model, number_of_outputs, device)
    labels = [cat_to_name[str(index + 1)] for index in np.array(probabilities[1][0])]
    probability = np.array(probabilities[0][0])
    i=0
    while i < number_of_outputs:
        print("{} with a probability of {}".format(labels[i], probability[i]))
        i += 1
    print("Finished Predicting!")

    
if __name__== "__main__":
    main()